var img1;
var img2;
var timg;

function preload()
{
  img1 = loadImage("flower.jpg");
  img2 = loadImage("pond.jpg");
  timg = loadImage("duck.gif");
}

function setup() {
  createCanvas(1500, 1500);
  textFont("Georgia");
  fill(130);
  stroke(80);
}

function draw() {
  background(230);
  textSize(50);
  if (mouseIsPressed) {
    image(img1,0,0,mouseX,mouseY);
  }
  else {
    image(img1,0,0, 200,200);
  }
  image(img2,400,0,600,600);
  image(timg,mouseX,mouseY);
  text("ducks are pretty funny", 500,50);
  text("ducks live in ponds and probably like flowers",500,125,200,600);
}