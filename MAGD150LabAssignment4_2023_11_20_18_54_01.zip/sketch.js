var speed = 3;
var x1 = 250;
var x2 = 400;
var y1 = 250;
var y2 = 150;
var canvasX = 500;
var canvasY = 500;
var frontRectWidth = 100;
var backRectWidth = 100;
var laserY = 285;
var laserXS = 250;
var laserXE = 10250;
var backgroundRectX = 0;
var backgroundRectY = 0;
var backgroundRectColor = 200;

function setup() {
  createCanvas(canvasX, canvasY);
}

function draw() {
background(220);
  for(let i=0;i<10;i++)
    {
      for(let j=0;j<10;j++)
        {
          fill(backgroundRectColor);
          rect(backgroundRectX,backgroundRectY,50,50);
          backgroundRectX += 50;
          if(backgroundRectColor == 200)
            {
              backgroundRectColor = 255;
            }
          else if(backgroundRectColor == 255)
            {
              backgroundRectColor = 200;
            }
        }
      backgroundRectY += 50;
      backgroundRectX = 0;
    }
  fill(255);
  //creates player character
  ellipse(x1,y1,30,30);
  line(x1,y1+15,x1,y1+70);
  line(x1,y1+70,x1+10,y1+90);
  line(x1,y1+70,x1-10,y1+90);
  line(x1,y1+35,x1+10,y1+55);
  line(x1,y1+35,x1-10,y1+55);
  //creates other character
  ellipse(x2,y2,30,30);
  line(x2,y2+15,x2,y2+70);
  line(x2,y2+70,x2+10,y2+90);
  line(x2,y2+70,x2-10,y2+90);
  line(x2,y2+35,x2+10,y2+55);
  line(x2,y2+35,x2-10,y2+55);
  rect(x2-50, y2-40, backRectWidth,10);
  fill(255,0,0);
  rect(x2-50, y2-40, frontRectWidth,10);
  
  if (keyIsPressed) 
  {
    if((key == 'w') && (y1>=20))
      {
        y1 -= speed;
      }
    else if((key == 'a') && (x1>=20))
      {
        x1 -=speed;
      }
    else if((key == 's') && (y1<=480))
      {
        y1 += speed;
      }
    else if((key == 'd') && (x1<= 480))
      {
        x1+=speed;
      }
   // else if((key == 'D') && (x1<= 480))
   //   {
   //     x1+=(speed/2);
    //  }
   // else if((key == 'A') && (x1>= 20))
   //   {
    //    x1-=(speed/2);
   //   }
   // else if((key =='W') && (y1>=20))
    //  {
   //     y1-=(speed/2);
    //  }
  }

  if (mouseIsPressed)
    {
      if(mouseButton == LEFT)
        {
          strokeWeight(5);
          stroke(230,0,0);
          line(x1, y1+35, x1+10000, y1+35);
          strokeWeight(1);
          stroke(0);
          if((x1<x2) && (y1+35 > y2-15) && (y1+35 < y2+90) && (frontRectWidth >= 0))
             {
             frontRectWidth -= 1;
             }
        }
    }
  backgroundRectX = 0;
  backgroundRectY = 0;
}